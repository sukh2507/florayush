import React from 'react'
import Card from './Card'

const Slider = (props) => {
  return (
    <>
    
    <section class="text-black body-font colorback reduced-padding">
        <h1 class="text-2xl font-bold text-center flex-grow">{props.title}</h1>

        <div class="marquee-container">
            {/* <!-- <marquee behavior="" direction=""> --> */}
            <div className="marquee-content">
       <Card category={"Plants Name"} title={"Plant #1"} desc={"Basic Info"} content={"some info"} />
       <Card category={"Plants Name"} title={"Plant #2"} desc={"Basic Info"} content={"some info"} />
       <Card category={"Plants Name"} title={"Plant #3"} desc={"Basic Info"} content={"some info"} />
       <Card category={"Plants Name"} title={"Plant #4"} desc={"Basic Info"} content={"some info"} />
       <Card category={"Plants Name"} title={"Plant #5"} desc={"Basic Info"} content={"some info"} />
                
            </div>
        {/* </marquee> */}
        </div>
    </section>

    </>
  )
}

export default Slider