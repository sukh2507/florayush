import React from 'react'
import Navbar from '../navbar'
import { Helmet } from 'react-helmet'
const Login = () => {
  return (
    <>
    <div style={{ marginTop: "-4.4%" }} className="min-h-screen z-50 bg-gray-900 flex  flex-col">
      <Helmet>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
        <title>FlorAyush</title>
        <link rel="icon" href="https://images.unsplash.com/photo-1725868904830-165e35d22ae6?q=80&w=1966&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />

      </Helmet>
    <Navbar mt="mt-10"/><br />
    {/* <h1 className='text-white'>This is login Page</h1> */}
    <br /><br />

      <section style={
        {
          marginTop:"-9rem",
          
        }
      } className="flex-grow flex items-center justify-center text-gray-400">
        <div className="w-full pt-8 pb-5 bg-gray-900 ring-gray-900/5 sm:rounded-xl sm:px-10">
          <center><h1 className="text-3xl font-bold justify-center text-center"><br /><br />Login to your account</h1></center>
          <form className='mt-8'><br /><br />
            <div className="relative mt-6">
              <input
                style={{
                  height: '3.3rem',
                  border: '2px solid',
                  borderRadius: '20px',
                  width: '35%',
                }}
                type="text"
                name="User_Id"
                id="User_Id"
                placeholder="                                     User Id"
                className="h-12 w-100 border-2 border-gray-300 rounded-full px-4 py-2 text-gray-800 focus:border-gray-500 focus:outline-none"
              />
            </div>
            <div className="relative mt-6">
              <input
                style={{
                  height: '3.2rem',
                  border: '2px solid',
                  borderRadius: '20px',
                  width: '35%',
                }}
                type="password"
                name="password"
                id="password"
                placeholder="                                   Password"
                className="h-12 border-2 border-gray-300 rounded-full px-4 py-2 text-gray-800 focus:border-gray-500 focus:outline-none"
              />
            </div>
            <div className="my-6">
              <button type="submit" className="w-60 rounded-full bg-black px-4 py-4 text-white focus:bg-gray-600 focus:outline-none">
                Sign in
              </button>
            </div>
          </form>
        </div>
      </section>
    </div>
</>
  )
}

export default Login