import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import reactLogo from './assets/flora.png';
// import viteLogo from '/vite.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './navbar';
import Slider from './components/Plants_slider';
import Card from './components/Card';
import Mentor from './components/Mentor_slider';
// import Team from './components/Team_slider';
import { createBrowserRouter , RouterProvider } from 'react-router-dom';
import Login from './components/Login';
import About from './components/About';
import Explore from './components/Explore';
import Order from './components/Order';
import Contact from './components/Contact';
import Metaverse from './components/Metaverse';
import { NavLink } from 'react-router-dom';
import Ourteam from './components/Ourteam';

// Website Component - moved outside of App component
function Website() {
  return (
    <>
      <div style={{ marginTop: "-4.4%" }} className="min-h-screen z-50 bg-gray-900 flex  flex-col">
        <Helmet>
          <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
          <title>FlorAyush</title>
          <link className='rounded-full ' rel="icon" href="https://images.unsplash.com/photo-1725868904830-165e35d22ae6?q=80&w=1966&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />
        </Helmet>

        {/* Navbar */}
        <Navbar mt="mt-20"/>

        {/* slider */}
        <section class="text-black body-font colorback reduced-padding">
          <h1 class="text-2xl font-bold text-center flex-grow">Experience Metaverse</h1><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
          <center>
            <NavLink to="/metaverse">
              <button className="bg-gray-700 text-white hover:bg-black hover:text-indigo-500 flex items-center justify-center text-center p-2 w-34 rounded-lg">
                Enter Metaverse
              </button>
            </NavLink>
          </center>
          <br /><br />  
        </section>

        <Slider title={"Ayurvedic Plants & Medicines"} />
        <Mentor title={"Mentors"} />
        {/* <Team title={"Our Team"} /> */}
      </div>
    </>
  );
}

function App() {
  const [data, setData] = useState(null);

  useEffect(() => {
    // Fetch data from the backend
    fetch('http://localhost:3000/route')
      .then((response) => response.json())
      .then((data) => {
        setData(data); // Set the retrieved data to the state
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  console.log(data);
  
  const router = createBrowserRouter([
    {
      path: '/',
      element: <Website />,
    },
    {
      path: '/login',
      element: <Login />,
    },
    {
      path: '/about-us',
      element: <About />,
    },
    {
      path: '/explore-plants',
      element: <Explore />,
    },
    {
      path: '/order-plants',
      element: <Order />,
    },
    {
      path: '/contact',
      element: <Contact />,
    },
    {
      path: '/metaverse',
      element: <Metaverse />,
    },
    {
      path: '/our-team',
      element: <Ourteam />,
    },
  ]);

  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
